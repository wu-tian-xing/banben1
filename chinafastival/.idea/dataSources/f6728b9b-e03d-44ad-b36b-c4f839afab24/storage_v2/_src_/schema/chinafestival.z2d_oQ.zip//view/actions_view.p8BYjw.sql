create definer = root@localhost view actions_view as
select `chinafestival`.`actions_user`.`u_id`  AS `u_id`,
       `chinafestival`.`actions`.`informatin` AS `informatin`,
       `chinafestival`.`actions`.`title`      AS `title`,
       `chinafestival`.`actions_user`.`a_id`  AS `a_id`,
       `chinafestival`.`actions`.`endtime`    AS `endtime`,
       `chinafestival`.`actions`.`starttime`  AS `starttime`,
       `chinafestival`.`actions`.`place`      AS `place`,
       `chinafestival`.`actions`.`picture`    AS `picture`,
       `chinafestival`.`actions`.`joinpeople` AS `joinpeople`,
       `chinafestival`.`actions`.`statecode`  AS `statecode`,
       `chinafestival`.`actions`.`sort`       AS `sort`,
       `chinafestival`.`actions`.`way`        AS `way`,
       `chinafestival`.`actions`.`needpeople` AS `needpeople`
from (`chinafestival`.`actions`
         join `chinafestival`.`actions_user`
              on ((`chinafestival`.`actions`.`a_id` = `chinafestival`.`actions_user`.`a_id`)));

